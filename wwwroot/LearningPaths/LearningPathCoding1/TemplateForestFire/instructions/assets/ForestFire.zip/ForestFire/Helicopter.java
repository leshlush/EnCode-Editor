import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Helicopter extends Actor
{
    private int speed;
    
    public Helicopter()
    {
      speed = 2;
    }
    
    public void act() 
    {
       
    } 
}
