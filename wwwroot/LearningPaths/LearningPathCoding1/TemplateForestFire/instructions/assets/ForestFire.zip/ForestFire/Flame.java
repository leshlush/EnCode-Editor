import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Flame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Flame extends SmoothMover
{
    private int speed;
        
    public Flame()
    {
        speed = 1;
    }
    
    
    public void act() 
    {
       
    }
    
    
}
